public enum CollisionType {
    case left
    case right
    case upper
    case lower
}
